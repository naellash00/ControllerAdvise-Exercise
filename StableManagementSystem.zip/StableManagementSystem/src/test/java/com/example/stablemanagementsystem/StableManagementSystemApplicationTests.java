package com.example.stablemanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StableManagementSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
