package com.example.stablemanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StableManagementSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(StableManagementSystemApplication.class, args);
    }

}
