package com.example.stablemanagementsystem.ApiResponse;

public class ApiException extends RuntimeException{
    public ApiException(String message){
        super(message);
    }
}
